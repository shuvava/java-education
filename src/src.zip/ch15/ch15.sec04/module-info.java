/*
@SuppressWarnings("module")
module ch15.sec04 {
   requires java.desktop;
}
*/
