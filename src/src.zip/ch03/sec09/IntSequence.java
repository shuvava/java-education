package ch03.sec09;

public interface IntSequence {
    boolean hasNext();
    int next();
}